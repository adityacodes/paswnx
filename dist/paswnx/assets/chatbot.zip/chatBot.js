var natural = require('natural');
var intents = require('./intents.json');
var tf = require('@tensorflow/tfjs');
var fs = require('fs');

class ChatBot {

    constructor() {
        this.words = [];
        this.documents = [];
        this.classes = [];
        this.linearModel = tf.sequential();
        this.tokenizer = new natural.WordTokenizer();
        this.stemmer = natural.LancasterStemmer;
        this.intents = intents;
        this.training = [];
        this.xs = [];
        this.ys = [];
        this.xd = {};
        this.yd = {};
        this.prediction = [];
        this.responses = [];
        this.isTrained = false;
    }

    async init() {
        this.cleanData();
        await this.trainModel();
    }

    cleanData() {
        let classSet = new Set();
        this.intents.forEach(intent => {
            intent.patterns.forEach(pattern => {
                let w = this.tokenizer.tokenize(pattern);
                this.words.push(w);
                this.documents.push([w, intent.tag]);
                classSet.add(intent.tag);
                this.responses[intent.tag] = intent.responses;
            });
        });
        this.classes = Array.from(classSet).sort();
        let newwords = new Set();
        this.words.forEach( word => word.forEach( w => newwords.add( this.stemmer.stem(w.toLowerCase()) ) ) );
        this.words = Array.from(newwords).sort();

        this.documents.forEach(doc => {
            let outputEmpty = Array(this.classes.length).fill(0);
            let bag = [];
            let npw = [];
            let patternWords = doc[0];
            patternWords.forEach(word => npw.push( this.stemmer.stem( word.toLowerCase() )));
            this.words.forEach(w => npw.includes(w)? bag.push(1) : bag.push(0));
            let outputRow = outputEmpty;
            outputRow[this.classes.indexOf(doc[1])] = 1;
            this.xs.push(bag);
            this.ys.push(outputRow);
            this.training.push([bag, outputRow]);
        });
        
        this.training = tf.tensor(this.training);
        tf.util.shuffle(this.training);
        this.xd = tf.tensor(this.xs);
        this.yd = tf.tensor(this.ys);
    }

    async trainModel() {
        this.linearModel.add(tf.layers.dense({ inputShape: [this.xs[0].length], units: 128, activation: 'relu'}));
        this.linearModel.add(tf.layers.dropout({rate: 0.5}));
        this.linearModel.add(tf.layers.dense({units: 64, activation: 'relu'}));
        this.linearModel.add(tf.layers.dropout({rate: 0.5}));
        this.linearModel.add(tf.layers.dense({units: this.ys[0].length, activation: 'softmax'}));
        let sgd = tf.train.momentum(0.01, 0.9, true);
        this.linearModel.compile({loss: 'categoricalCrossentropy', optimizer: sgd, metrics: ['accuracy']});
        const batchSize = 5;
        const epochs = 200;
        const verbose = 1;

        function onEpochBegin(epoch, logs){
            console.log("Epoch: "+ epoch + "/" + epochs);
        }

        await this.linearModel.fit(this.xd, this.yd, {
            batchSize,
            epochs,
            verbose,
            shuffle: true,
            callbacks: {onEpochBegin} 
        }).then(info => {
            this.isTrained = true;
            console.log("Finished Training");
        });
        
        
    }
    // Used for sorting down below
    compare(a, b){

    }

    async predict(sentence) {
        if(this.isTrained) {
            let sentenceWords = this.tokenizer.tokenize(sentence);
            let nsw = new Set();
            sentenceWords.forEach(word => nsw.add( this.stemmer.stem(word.toLowerCase())));
            sentenceWords = Array.from(nsw).sort();
        
            let bag = Array(this.words.length).fill(0); 
            
            // Marking words present as 1 down below 
            sentenceWords.forEach( s => {
                this.words.forEach( ( w, i ) => {
                    if(w == s){
                        bag[i] = 1;
                        console.log( "Found: " + w );
                    }
                });           
            });

            let ERROR_THRESHOLD = 0.25;
            let results = this.linearModel.predict([tf.tensor2d([bag])]);
            this.prediction = Array.from(results.dataSync());

            let nr = [];
            this.prediction.forEach((r, i) => {
                if (r > ERROR_THRESHOLD)
                    nr.push([i,r]);
            });    
            let returnList = [];
            nr.forEach(r => {
                returnList.push({ intent: this.classes[r[0]], accuracy: r[1], responses: this.responses[this.classes[r[0]]] });
            });
            // Reverse sort by accuracy here. TO be done!
            return {data: returnList };
        }else{
            return {data: "Model not yet trained"};
        }
        // return ;
    }
}

module.exports = ChatBot;


