var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var fs = require('fs');
var list_of_intents = JSON.parse(fs.readFileSync('intents.json', 'utf8'));

var ChatBot = require('./chatBot');
var chatBot = new ChatBot();
chatBot.init();

app.get('/', function(req, res){
    res.sendFile(__dirname + '/index.html');
});

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

io.on('connection', function(socket){
    console.log('a user connected');
    socket.on('chat message', function(msg){
        io.emit('chat message', msg);

        chatBot.predict(msg).then((data) => {
            io.emit('serverResponse', JSON.stringify(data));
        });
    });

    socket.on('disconnect', function(){
      console.log('user disconnected'); 
    });
});


http.listen(3000, function(){
  console.log('Server Listening on *:3000');
});